<?php
return [
    'software' => [
        'name'      => 'Flutter Music Pro',
        'author'    => 'Ratanak Ieng',
        'url'       => 'https://khmertracks.com',
        'version'   => '1.0.0'
    ]
];
