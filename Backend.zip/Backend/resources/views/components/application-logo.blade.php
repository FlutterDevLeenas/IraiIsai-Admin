<img src="{{ url('/') }}/uploads/brand/{{ config('settings.logo') ?? 'logo.png' }}" alt="{{ config('app.name') }}" class="block h-9 w-auto fill-current text-gray-800 dark:text-gray-200"/>
